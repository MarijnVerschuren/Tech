#ifndef EVENTS_H
#define EVENTS_H

enum Events
{
    EV_START,
    EV_TIME_UP
};

#endif
