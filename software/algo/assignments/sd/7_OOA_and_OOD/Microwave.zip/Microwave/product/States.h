#ifndef STATES_H
#define STATES_H

enum States
{
    STATE_IDLE,
    STATE_HEATING
};

#endif
