#ifndef REALTIME_H
#define REALTIME_H

double getRealTime(void);

#endif
