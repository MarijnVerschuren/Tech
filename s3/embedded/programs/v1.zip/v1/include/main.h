//
// Created by marijn on 2/13/23.
//

#ifndef STM32F303RET6_MAIN_H
#define STM32F303RET6_MAIN_H
#include "stm32f3xx.h"


void sys_clock_init(void);


#endif //STM32F303RET6_MAIN_H
