#ifndef TASKS_H
#define TASKS_H

enum Tasks {
    NO_INDICATOR = 0,	// program select
    WAITING = 1,
    KNEADING = 2,
    RISING = 3,
    BAKING = 4,
    DONE = 5
};

#endif
