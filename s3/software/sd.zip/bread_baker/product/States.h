#ifndef STATES_H
#define STATES_H

enum States {
    STANDBY,
	PROCESSING
};

#endif
