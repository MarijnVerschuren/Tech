#include <iostream>

using namespace std;

int main(){
    int t,n,m;
    int route_count=0;
    
    cin >> t ;
    for(int i=0; i<t; i++)
    {
 	cin >> n >> m;
	/* store the values to your own data structure */
	/* execute your algorithm for each test */
	/* store result (shortest route) of each test in route_count */
	route_count=0;
        cout << route_count<<endl;
    }
    return 0;

}
