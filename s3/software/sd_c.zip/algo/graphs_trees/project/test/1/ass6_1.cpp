#include <iostream>

using namespace std;

int main()
{
	int n;
	cin >> n;

	for(int i=0;i<n;i++)
	{
		int nr, left, right;
		cin >> nr >> left >> right;
	}
	int depth = 0;
	/* implement your algorithm and store the tree depth in depth */
	cout << "depth is " << depth << endl;
	return 0;
}
