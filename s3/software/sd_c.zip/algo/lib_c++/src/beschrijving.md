We are going to start getting acquainted with C++ and GoogleTest framework.
