Two basic abstract data structures - stacks and queues and corresponding FIFO and LIFO principles are explained. Typical situation in which stacks and queues are used are shown. 
