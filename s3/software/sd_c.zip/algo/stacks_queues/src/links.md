## Weblinks

+ Assignment code can be found in git.fhict.nl repository t-sem3-cb-code
+ [Embedded Software: Copying Memory with memcpy ](https://www.youtube.com/watch?v=SjR_LOOzsMQ&t=45s)
