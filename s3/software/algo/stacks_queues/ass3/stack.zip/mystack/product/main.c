#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>

#include "mystack.h"


int main () {
  printf("Hello world!\n");
  return 0;
}
