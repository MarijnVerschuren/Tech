We exercise with recursion and making a proper data structure to ease recursive calls using C++ (advance) features. 
